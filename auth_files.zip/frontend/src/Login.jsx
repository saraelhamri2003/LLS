import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext.jsx';

const Login = () => {
  const { user, loading, login, error } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitError, setSubmitError] = useState(null);
  const [working, setWorking] = useState(false);

  useEffect(() => {
    if (!loading && user) {
      navigate('/');
    }
  }, [loading, user, navigate]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    setSubmitError(null);
    setWorking(true);
    try {
      await login(email.trim(), password);
      navigate('/');
    } catch (err) {
      setSubmitError(err.message || 'Login failed.');
    } finally {
      setWorking(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#f4f1ea] dark:bg-[#0b1220] flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md rounded-[32px] bg-white/95 shadow-[0_20px_60px_rgba(15,23,42,0.16)] p-8 backdrop-blur dark:bg-slate-900/95">
        <h1 className="text-3xl font-semibold mb-3 text-slate-900 dark:text-white">Connexion</h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
          Connectez-vous pour accéder à votre assistant Lean Six Sigma et à l’administration.
        </p>
        <form onSubmit={handleSubmit} className="space-y-4">
          <label className="block">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Email</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-2 w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-slate-500 focus:ring-2 focus:ring-slate-200 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              required
            />
          </label>
          <label className="block">
            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">Mot de passe</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="mt-2 w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none transition focus:border-slate-500 focus:ring-2 focus:ring-slate-200 dark:border-slate-700 dark:bg-slate-950 dark:text-white"
              required
            />
          </label>
          {submitError && <div className="text-sm text-rose-600">{submitError}</div>}
          {error && !submitError && <div className="text-sm text-rose-600">{error}</div>}
          <button
            type="submit"
            disabled={working}
            className="button-primary w-full py-3"
          >
            {working ? 'Connexion...' : 'Se connecter'}
          </button>
        </form>
      </div>
    </main>
  );
};

export default Login;
