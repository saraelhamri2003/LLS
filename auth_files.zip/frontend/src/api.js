export const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:5001';

const defaultHeaders = (headers = {}) => {
  const base = {
    'Content-Type': 'application/json',
    ...headers
  };

  try {
    if (typeof window !== 'undefined') {
      const token = sessionStorage.getItem('l6s_token');
      if (token) {
        base['Authorization'] = `Bearer ${token}`;
      }
    }
  } catch (e) {
    // ignore
  }

  return base;
};

export async function fetchJson(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    credentials: 'include',
    headers: defaultHeaders(options.headers),
    ...options
  });

  const text = await response.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (error) {
    throw new Error(`Invalid JSON response from ${path}`);
  }

  if (!response.ok) {
    throw new Error(data?.error || `Request failed (${response.status})`);
  }

  return data;
}
