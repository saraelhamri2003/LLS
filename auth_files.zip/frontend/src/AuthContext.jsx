import React, { createContext, useContext, useEffect, useState } from 'react';
import { fetchJson } from './api.js';

const AuthContext = createContext({
  user: null,
  loading: true,
  error: null,
  login: async () => {},
  logout: async () => {},
  refreshUser: async () => {}
});

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refreshUser = async () => {
    setLoading(true);
    try {
      const data = await fetchJson('/auth/me', { method: 'GET' });
      setUser(data);
      setError(null);
    } catch (err) {
      setUser(null);
      setError(null);
    } finally {
      setLoading(false);
    }
  };

  const login = async (email, password) => {
    setLoading(true);
    try {
      const data = await fetchJson('/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      // store token for Authorization header usage in fetch helper
      try { sessionStorage.setItem('l6s_token', data.token); } catch (e) {}
      setUser(data.user);
      setError(null);
      return data.user;
    } catch (err) {
      setUser(null);
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const logout = async () => {
    setLoading(true);
    try {
      await fetchJson('/auth/logout', { method: 'POST' });
      try { sessionStorage.removeItem('l6s_token'); } catch (e) {}
      setUser(null);
      setError(null);
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, error, login, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
