﻿import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';
import sqlite3 from 'sqlite3';
import { open } from 'sqlite';
import { hashPassword, publicUser } from './auth.js';

const VALID_ROLES = new Set(['admin', 'user']);

export class UsersStore {
  constructor(dbPath) {
    this.dbPath = dbPath;
    this.db = null;
  }

  async initialize() {
    await fs.mkdir(path.dirname(this.dbPath), { recursive: true });
    this.db = await open({
      filename: this.dbPath,
      driver: sqlite3.Database
    });
    await this.db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
    `);
    await this.ensureInitialAdmin();
  }

  normalizeEmail(email) {
    return String(email || '').trim().toLowerCase();
  }

  validateRole(role) {
    const normalized = String(role || 'user').trim().toLowerCase();
    if (!VALID_ROLES.has(normalized)) {
      const error = new Error('Role must be admin or user');
      error.status = 422;
      throw error;
    }
    return normalized;
  }

  validatePassword(password) {
    if (!password || String(password).length < 8) {
      const error = new Error('Password must contain at least 8 characters');
      error.status = 422;
      throw error;
    }
  }

  async ensureInitialAdmin() {
    const admin = await this.db.get('SELECT id FROM users WHERE role = ? LIMIT 1', ['admin']);
    if (admin) return;

    const email = this.normalizeEmail(process.env.ADMIN_EMAIL || 'admin@lss.com');
    const password = process.env.ADMIN_PASSWORD || 'Admin123!';
    const now = new Date().toISOString();
    await this.db.run(
      `INSERT INTO users (id, email, password_hash, role, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [crypto.randomUUID(), email, hashPassword(password), 'admin', now, now]
    );
    console.warn(`Initial admin account created: ${email}`);
    if (!process.env.ADMIN_PASSWORD) {
      console.warn('WARNING: ADMIN_PASSWORD is not set. Default password is Admin123!');
    }
  }

  async listUsers() {
    const users = await this.db.all(`
      SELECT id, email, role, created_at AS createdAt, updated_at AS updatedAt
      FROM users
      ORDER BY lower(email) ASC
    `);
    return users.map(publicUser);
  }

  async getUserById(id) {
    return this.db.get(
      `SELECT id, email, role, password_hash AS passwordHash, created_at AS createdAt, updated_at AS updatedAt
       FROM users
       WHERE id = ? LIMIT 1`,
      [id]
    );
  }

  async getUserByEmail(email) {
    const normalized = this.normalizeEmail(email);
    return this.db.get(
      `SELECT id, email, role, password_hash AS passwordHash, created_at AS createdAt, updated_at AS updatedAt
       FROM users
       WHERE email = ? LIMIT 1`,
      [normalized]
    );
  }

  async createUser({ email, password, role = 'user' }) {
    const normalizedEmail = this.normalizeEmail(email);
    if (!normalizedEmail || !normalizedEmail.includes('@')) {
      const error = new Error('A valid email is required');
      error.status = 422;
      throw error;
    }
    this.validatePassword(password);
    const normalizedRole = this.validateRole(role);

    const existing = await this.getUserByEmail(normalizedEmail);
    if (existing) {
      const error = new Error('Email already exists');
      error.status = 409;
      throw error;
    }

    const now = new Date().toISOString();
    const id = crypto.randomUUID();
    await this.db.run(
      `INSERT INTO users (id, email, password_hash, role, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, normalizedEmail, hashPassword(password), normalizedRole, now, now]
    );

    return publicUser({ id, email: normalizedEmail, role: normalizedRole, createdAt: now, updatedAt: now });
  }

  async updateUser(id, { email, role }) {
    const user = await this.getUserById(id);
    if (!user) {
      const error = new Error('User not found');
      error.status = 404;
      throw error;
    }

    const normalizedEmail = this.normalizeEmail(email ?? user.email);
    if (!normalizedEmail || !normalizedEmail.includes('@')) {
      const error = new Error('A valid email is required');
      error.status = 422;
      throw error;
    }

    if (normalizedEmail !== user.email) {
      const existing = await this.getUserByEmail(normalizedEmail);
      if (existing && existing.id !== id) {
        const error = new Error('Email already exists');
        error.status = 409;
        throw error;
      }
    }

    const normalizedRole = this.validateRole(role ?? user.role);
    const updatedAt = new Date().toISOString();

    await this.db.run(
      `UPDATE users SET email = ?, role = ?, updated_at = ? WHERE id = ?`,
      [normalizedEmail, normalizedRole, updatedAt, id]
    );

    return publicUser({ id, email: normalizedEmail, role: normalizedRole, createdAt: user.createdAt, updatedAt });
  }

  async updatePassword(id, password) {
    this.validatePassword(password);
    const user = await this.getUserById(id);
    if (!user) {
      const error = new Error('User not found');
      error.status = 404;
      throw error;
    }
    const updatedAt = new Date().toISOString();
    await this.db.run(
      `UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?`,
      [hashPassword(password), updatedAt, id]
    );
    return publicUser({ id, email: user.email, role: user.role, createdAt: user.createdAt, updatedAt });
  }

  async deleteUser(id, currentUserId) {
    if (id === currentUserId) {
      const error = new Error('You cannot delete your own account');
      error.status = 422;
      throw error;
    }
    const user = await this.getUserById(id);
    if (!user) {
      const error = new Error('User not found');
      error.status = 404;
      throw error;
    }

    const admins = await this.db.all(`SELECT id FROM users WHERE role = 'admin'`);
    if (admins.length <= 1 && user.role === 'admin') {
      const error = new Error('At least one admin account is required');
      error.status = 422;
      throw error;
    }

    await this.db.run(`DELETE FROM users WHERE id = ?`, [id]);
    return publicUser(user);
  }
}
