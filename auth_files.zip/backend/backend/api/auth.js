﻿import crypto from 'crypto';

const JWT_ALGORITHM = 'HS256';
const TOKEN_COOKIE_NAME = 'l6s_admin_token';

const base64url = (input) => Buffer.from(input)
  .toString('base64')
  .replace(/=/g, '')
  .replace(/\+/g, '-')
  .replace(/\//g, '_');

const base64urlJson = (value) => base64url(JSON.stringify(value));

const decodeBase64url = (value) => {
  const padded = value.replace(/-/g, '+').replace(/_/g, '/').padEnd(Math.ceil(value.length / 4) * 4, '=');
  return Buffer.from(padded, 'base64').toString('utf8');
};

const getJwtSecret = () => {
  const secret = process.env.JWT_SECRET || 'dev-only-change-this-jwt-secret';
  if (secret === 'dev-only-change-this-jwt-secret') {
    console.warn('WARNING: JWT_SECRET is not set. Using an insecure development secret.');
  }
  return secret;
};

const parseDurationSeconds = (value, fallbackSeconds = 8 * 60 * 60) => {
  if (!value) return fallbackSeconds;
  const match = String(value).trim().match(/^(\d+)([smhd])?$/i);
  if (!match) return fallbackSeconds;
  const amount = Number(match[1]);
  const unit = (match[2] || 's').toLowerCase();
  const multipliers = { s: 1, m: 60, h: 3600, d: 86400 };
  return amount * multipliers[unit];
};

const sign = (content) => crypto
  .createHmac('sha256', getJwtSecret())
  .update(content)
  .digest('base64')
  .replace(/=/g, '')
  .replace(/\+/g, '-')
  .replace(/\//g, '_');

export const createToken = (user) => {
  const now = Math.floor(Date.now() / 1000);
  const ttl = parseDurationSeconds(process.env.JWT_EXPIRES_IN, 8 * 60 * 60);
  const header = { alg: JWT_ALGORITHM, typ: 'JWT' };
  const payload = {
    sub: user.id,
    email: user.email,
    role: user.role,
    iat: now,
    exp: now + ttl
  };
  const unsigned = `${base64urlJson(header)}.${base64urlJson(payload)}`;
  return `${unsigned}.${sign(unsigned)}`;
};

export const verifyToken = (token) => {
  if (!token || typeof token !== 'string') return null;
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [encodedHeader, encodedPayload, signature] = parts;
  const unsigned = `${encodedHeader}.${encodedPayload}`;
  const expected = sign(unsigned);
  const signatureBuffer = Buffer.from(signature);
  const expectedBuffer = Buffer.from(expected);
  if (signatureBuffer.length !== expectedBuffer.length || !crypto.timingSafeEqual(signatureBuffer, expectedBuffer)) {
    return null;
  }
  try {
    const header = JSON.parse(decodeBase64url(encodedHeader));
    const payload = JSON.parse(decodeBase64url(encodedPayload));
    if (header.alg !== JWT_ALGORITHM || payload.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return payload;
  } catch (error) {
    return null;
  }
};

export const hashPassword = (password) => {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `scrypt$${salt}$${hash}`;
};

export const verifyPassword = (password, storedHash) => {
  if (!storedHash || typeof storedHash !== 'string') return false;
  const [scheme, salt, hash] = storedHash.split('$');
  if (scheme !== 'scrypt' || !salt || !hash) return false;
  const candidate = crypto.scryptSync(String(password), salt, 64);
  const expected = Buffer.from(hash, 'hex');
  return candidate.length === expected.length && crypto.timingSafeEqual(candidate, expected);
};

export const publicUser = (user) => ({
  id: user.id,
  email: user.email,
  role: user.role,
  createdAt: user.createdAt,
  updatedAt: user.updatedAt
});

export const readCookieToken = (req) => {
  const cookieHeader = req.headers.cookie || '';
  const cookies = Object.fromEntries(cookieHeader.split(';').map((part) => {
    const index = part.indexOf('=');
    if (index === -1) return ['', ''];
    return [part.slice(0, index).trim(), decodeURIComponent(part.slice(index + 1).trim())];
  }).filter(([key]) => key));
  return cookies[TOKEN_COOKIE_NAME] || null;
};

export const readBearerToken = (req) => {
  const header = req.headers.authorization || '';
  const match = header.match(/^Bearer\s+(.+)$/i);
  return match ? match[1] : null;
};

export const setAuthCookie = (res, token) => {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${TOKEN_COOKIE_NAME}=${encodeURIComponent(token)}; HttpOnly; SameSite=None; Path=/; Max-Age=${parseDurationSeconds(process.env.JWT_EXPIRES_IN)}${secure}`);
};

export const clearAuthCookie = (res) => {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `${TOKEN_COOKIE_NAME}=; HttpOnly; SameSite=None; Path=/; Max-Age=0${secure}`);
};

export const requireAuth = (usersStore) => async (req, res, next) => {
  const token = readBearerToken(req) || readCookieToken(req);
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Authentication required' });
  }
  const user = await usersStore.getUserById(payload.sub);
  if (!user) {
    return res.status(401).json({ error: 'Invalid session' });
  }
  req.user = publicUser(user);
  next();
};

export const requireAdmin = (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Admin role required' });
  }
  next();
};
